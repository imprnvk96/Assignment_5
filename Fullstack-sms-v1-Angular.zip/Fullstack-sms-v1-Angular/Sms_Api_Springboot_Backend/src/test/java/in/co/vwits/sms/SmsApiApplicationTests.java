package in.co.vwits.sms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
