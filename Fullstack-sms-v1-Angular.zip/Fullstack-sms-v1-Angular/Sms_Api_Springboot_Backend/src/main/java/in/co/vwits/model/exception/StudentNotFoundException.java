package in.co.vwits.model.exception;

public class StudentNotFoundException extends Exception {

}
