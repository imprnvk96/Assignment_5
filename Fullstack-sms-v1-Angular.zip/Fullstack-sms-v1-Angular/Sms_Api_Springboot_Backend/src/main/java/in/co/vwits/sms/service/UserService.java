package in.co.vwits.sms.service;

import in.co.vwits.sms.model.User;

public interface UserService {

	User authenticate(User u);

}