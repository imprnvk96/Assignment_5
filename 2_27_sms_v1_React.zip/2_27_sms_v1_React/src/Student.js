import React from "react";
import Menu from "./Menu";

const Student = () => {
  return (
    <div>
      <Menu> </Menu>
    </div>
  );
};

export default Student;
