import React from "react";

const Menu = () => {
  return (
    <div>
      <a href="login">Login</a>
      <a href="Students">Students</a>
      <a href="logout">Logout</a>
      <a href="login">Login</a>
    </div>
  );
};

export default Menu;
