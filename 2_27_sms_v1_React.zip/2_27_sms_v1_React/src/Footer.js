export default function Footer() {
  return <h3>Footer here</h3>;
}
