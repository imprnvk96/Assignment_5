function Header() {
  // whatever we return from a component in react is known as JSX
  // JavaScript XML
  // Which is HTML with JS in it
  // As name contains XML, we must make sure that while returning, whole content
  // must be enclosed in one single tag.
  return <h1> Student Management System</h1>;
}
export default Header;
